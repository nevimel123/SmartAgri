package com.example.smartagri

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

class DashboardActivity : Activity() {

    // UI Components
    private lateinit var tvGreeting: TextView
    private lateinit var tvDate: TextView
    private lateinit var cardGrowthPhase: CardView
    private lateinit var cardDeviceA: CardView
    private lateinit var cardDeviceB: CardView
    private lateinit var progressDeviceA: ProgressBar
    private lateinit var progressDeviceB: ProgressBar

    // Time period buttons
    private lateinit var btnWeekly: TextView
    private lateinit var btnMonthly: TextView
    private lateinit var btnYearly: TextView

    // Bottom navigation
    private lateinit var navHome: LinearLayout
    private lateinit var navWeather: LinearLayout
    private lateinit var navSOS: LinearLayout
    private lateinit var navIrrigation: LinearLayout
    private lateinit var navNotify: LinearLayout
    private lateinit var navAccount: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        initializeViews()
        setupGreeting()
        setupClickListeners()
        setupAnalytics()
        setupBottomNavigation()

    }

    private fun initializeViews() {
        tvGreeting = findViewById(R.id.tvGreeting)
        tvDate = findViewById(R.id.tvDate)

        cardGrowthPhase = findViewById(R.id.cardGrowthPhase)
        cardDeviceA = findViewById(R.id.cardDeviceA)
        cardDeviceB = findViewById(R.id.cardDeviceB)

        progressDeviceA = findViewById(R.id.progressDeviceA)
        progressDeviceB = findViewById(R.id.progressDeviceB)

        btnWeekly = findViewById(R.id.btnWeekly)
        btnMonthly = findViewById(R.id.btnMonthly)
        btnYearly = findViewById(R.id.btnYearly)

        navHome = findViewById(R.id.navHome)
        navWeather = findViewById(R.id.navWeather)
        navSOS = findViewById(R.id.navSOS)
        navIrrigation = findViewById(R.id.navIrrigation)
        navNotify = findViewById(R.id.navNotify)
        navAccount = findViewById(R.id.navAccount)
    }

    private fun setupGreeting() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)

        val greeting = when {
            hour < 12 -> "Good Morning"
            hour < 17 -> "Good Afternoon"
            else -> "Good Evening"
        }

        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val firstName = sharedPref.getString("firstName", "User")

        tvGreeting.text = "$greeting, $firstName!"

        val dateFormat = SimpleDateFormat("EEEE, MMMM d yyyy", Locale.getDefault())
        tvDate.text = dateFormat.format(Date())
    }

    private fun setupClickListeners() {
        cardGrowthPhase.setOnClickListener {
            showToast("Select Growth Phase")
        }

        cardDeviceA.setOnClickListener {
            showToast("Device A - Moisture: 42%")
        }

        cardDeviceB.setOnClickListener {
            showToast("Device B - Moisture: 38%")
        }

        btnWeekly.setOnClickListener { selectTimePeriod(TimePeriod.WEEKLY) }
        btnMonthly.setOnClickListener { selectTimePeriod(TimePeriod.MONTHLY) }
        btnYearly.setOnClickListener { selectTimePeriod(TimePeriod.YEARLY) }
    }

    private fun setupBottomNavigation() {
        navHome.setOnClickListener {
            showToast("Home")
        }
        navWeather.setOnClickListener {
            val intent = Intent(this, WeatherActivity::class.java)
            startActivity(intent)
        }
        navSOS.setOnClickListener {
            showToast("SOS")
        }
        navIrrigation.setOnClickListener {
            showToast("Irrigation")
        }
        navNotify.setOnClickListener {
            showToast("Notifications")
        }
        navAccount.setOnClickListener {
            val intent = Intent(this, AccountSettingsActivity::class.java)
            startActivity(intent)
        }

    }

    private fun setupAnalytics() {
        progressDeviceA.progress = 55
        progressDeviceB.progress = 45
        selectTimePeriod(TimePeriod.WEEKLY)
    }

    private fun selectTimePeriod(period: TimePeriod) {
        resetTimePeriodButtons()
        when (period) {
            TimePeriod.WEEKLY -> {
                btnWeekly.setBackgroundResource(R.drawable.bg_tab_selected)
                btnWeekly.setTextColor(ContextCompat.getColor(this, R.color.white))
                btnWeekly.setTypeface(null, android.graphics.Typeface.BOLD)
            }
            TimePeriod.MONTHLY -> {
                btnMonthly.setBackgroundResource(R.drawable.bg_tab_selected)
                btnMonthly.setTextColor(ContextCompat.getColor(this, R.color.white))
                btnMonthly.setTypeface(null, android.graphics.Typeface.BOLD)
            }
            TimePeriod.YEARLY -> {
                btnYearly.setBackgroundResource(R.drawable.bg_tab_selected)
                btnYearly.setTextColor(ContextCompat.getColor(this, R.color.white))
                btnYearly.setTypeface(null, android.graphics.Typeface.BOLD)
            }
        }
    }

    private fun resetTimePeriodButtons() {
        val buttons = listOf(btnWeekly, btnMonthly, btnYearly)
        buttons.forEach { button ->
            button.setBackgroundResource(R.drawable.bg_tab_unselected)
            button.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
            button.setTypeface(null, android.graphics.Typeface.NORMAL)
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    enum class TimePeriod {
        WEEKLY, MONTHLY, YEARLY
    }
}
