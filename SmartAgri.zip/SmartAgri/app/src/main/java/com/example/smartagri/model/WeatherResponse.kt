package com.example.smartagri.model

import com.google.gson.annotations.SerializedName

data class WeatherResponse(
    val main: Main,
    val weather: List<Weather>,
    val wind: Wind,
    val rain: Rain? = null
)

data class Main(
    val temp: Double,
    val humidity: Int
)

data class Weather(
    val main: String,
    val description: String,
    val icon: String // Add icon code
)

data class Wind(
    val speed: Double
)

data class Rain(
    @SerializedName("1h") val oneHour: Double? = 0.0
)
