package com.example.smartagri

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.widget.*

class RegisterActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val firstName = findViewById<EditText>(R.id.firstnameInput)
        val lastName = findViewById<EditText>(R.id.lastnameInput)
        val email = findViewById<EditText>(R.id.emailInput)
        val address = findViewById<EditText>(R.id.addressInput)
        val password = findViewById<EditText>(R.id.regpasswordInput)
        val confirmPassword = findViewById<EditText>(R.id.confirmpasswordInput)
        val registerButton = findViewById<Button>(R.id.registerButton)
        val loginText = findViewById<TextView>(R.id.loginText)

        loginText.text = "Already have an account? Login"

        registerButton.setOnClickListener {
            if (!validateRegister(
                    firstName,
                    lastName,
                    email,
                    address,
                    password,
                    confirmPassword
                )
            ) return@setOnClickListener

            // Save user info in SharedPreferences
            val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            editor.putString("firstName", firstName.text.toString())
            editor.putString("lastName", lastName.text.toString())
            editor.putString("email", email.text.toString())
            editor.putString("address", address.text.toString())
            editor.putString("password", password.text.toString())
            editor.apply()

            Toast.makeText(this, "Registration successful", Toast.LENGTH_SHORT).show()
            finish()
        }

        loginText.setOnClickListener {
            finish()
        }
    }

    private fun validateRegister(
        firstName: EditText,
        lastName: EditText,
        email: EditText,
        address: EditText,
        password: EditText,
        confirmPassword: EditText
    ): Boolean {

        if (firstName.text.isEmpty()) {
            firstName.error = "Required"
            return false
        }

        if (lastName.text.isEmpty()) {
            lastName.error = "Required"
            return false
        }

        if (email.text.isEmpty()) {
            email.error = "Required"
            return false
        }

        if (address.text.isEmpty()) {
            address.error = "Required"
            return false
        }

        if (password.text.length < 6) {
            password.error = "At least 6 characters"
            return false
        }

        if (password.text.toString() != confirmPassword.text.toString()) {
            confirmPassword.error = "Passwords do not match"
            return false
        }

        return true
    }
}
