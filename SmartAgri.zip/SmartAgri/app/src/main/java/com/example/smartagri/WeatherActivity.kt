package com.example.weatherapp

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class WeatherActivity : AppCompatActivity() {

    private lateinit var tvTime: TextView
    private lateinit var tvTemperature: TextView
    private lateinit var tvCondition: TextView
    private lateinit var tvFeelsLike: TextView
    private lateinit var tvWind: TextView
    private lateinit var tvHumidity: TextView
    private lateinit var tvVisibility: TextView
    private lateinit var tvPressure: TextView
    private lateinit var tvUVIndex: TextView
    private lateinit var tvDewPoint: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weather)

        initViews()
        loadWeatherData()
    }

    private fun initViews() {
        tvTime = findViewById(R.id.tvTime)
        tvTemperature = findViewById(R.id.tvTemperature)
        tvCondition = findViewById(R.id.tvCondition)
        tvFeelsLike = findViewById(R.id.tvFeelsLike)
        tvWind = findViewById(R.id.tvWind)
        tvHumidity = findViewById(R.id.tvHumidity)
        tvVisibility = findViewById(R.id.tvVisibility)
        tvPressure = findViewById(R.id.tvPressure)
        tvUVIndex = findViewById(R.id.tvUVIndex)
        tvDewPoint = findViewById(R.id.tvDewPoint)
    }

    private fun loadWeatherData() {
        // Set current time
        val currentTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        tvTime.text = currentTime

        // Set weather data (this would normally come from an API)
        val weatherData = WeatherData(
            temperature = 78,
            feelsLike = 79,
            condition = "Overcast Clouds",
            wind = "10 mph NE",
            humidity = "79%",
            visibility = "6mi",
            pressure = "30 IN",
            uvIndex = "0 UV",
            dewPoint = "71°"
        )

        updateUI(weatherData)
    }

    private fun updateUI(data: WeatherData) {
        tvTemperature.text = "${data.temperature}°"
        tvFeelsLike.text = "Feels like ${data.feelsLike}°"
        tvCondition.text = data.condition
        tvWind.text = data.wind
        tvHumidity.text = data.humidity
        tvVisibility.text = data.visibility
        tvPressure.text = data.pressure
        tvUVIndex.text = data.uvIndex
        tvDewPoint.text = data.dewPoint
    }

    // Data class to hold weather information
    data class WeatherData(
        val temperature: Int,
        val feelsLike: Int,
        val condition: String,
        val wind: String,
        val humidity: String,
        val visibility: String,
        val pressure: String,
        val uvIndex: String,
        val dewPoint: String
    )
}