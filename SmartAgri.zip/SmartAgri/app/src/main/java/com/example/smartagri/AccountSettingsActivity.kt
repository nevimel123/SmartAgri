package com.example.smartagri

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast

class AccountSettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_settings)

        setupMenuItems()
        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        // Bottom navigation
        findViewById<LinearLayout>(R.id.navHome).setOnClickListener {
            val intent = Intent(this, DashboardActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }

        findViewById<LinearLayout>(R.id.navWeather).setOnClickListener {
            Toast.makeText(this, "Weather", Toast.LENGTH_SHORT).show()
             startActivity(Intent(this, WeatherActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.navSOS).setOnClickListener {
            Toast.makeText(this, "SOS", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, SosActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.navIrrigation).setOnClickListener {
            Toast.makeText(this, "Irrigation", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, IrrigationActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.navNotify).setOnClickListener {
            Toast.makeText(this, "Notifications", Toast.LENGTH_SHORT).show()
            // startActivity(Intent(this, NotificationActivity::class.java))
        }

        findViewById<LinearLayout>(R.id.navAccount).setOnClickListener {
            // Already on account screen
        }
    }

    private fun setupMenuItems() {
        // ACCOUNT Section
        setupMenuItem(
            itemId = R.id.itemRegisterDevice,
            iconRes = R.drawable.ic_device,
            title = "Register new device"
        ) {
            Toast.makeText(this, "Register new device clicked", Toast.LENGTH_SHORT).show()
            // Add your navigation or action here
        }

        setupMenuItem(
            itemId = R.id.itemViewProfile,
            iconRes = R.drawable.ic_account,
            title = "View Profile"
        ) {
            Toast.makeText(this, "View Profile clicked", Toast.LENGTH_SHORT).show()
            // Add your navigation or action here
        }

        // SAFETY Section
        setupMenuItem(
            itemId = R.id.itemTerms,
            iconRes = R.drawable.ic_terms,
            title = "Terms and Condition"
        ) {
            Toast.makeText(this, "Terms and Condition clicked", Toast.LENGTH_SHORT).show()
            // Add your navigation or action here
        }

        setupMenuItem(
            itemId = R.id.itemPrivacy,
            iconRes = R.drawable.ic_privacy,
            title = "Privacy Policy"
        ) {
            Toast.makeText(this, "Privacy Policy clicked", Toast.LENGTH_SHORT).show()
            // Add your navigation or action here
        }

        setupMenuItem(
            itemId = R.id.itemReport,
            iconRes = R.drawable.ic_report,
            title = "Report"
        ) {
            Toast.makeText(this, "Report clicked", Toast.LENGTH_SHORT).show()
            // Add your navigation or action here
        }

        // OTHERS Section
        setupMenuItem(
            itemId = R.id.itemChangePassword,
            iconRes = R.drawable.ic_password,
            title = "Change Password"
        ) {
            Toast.makeText(this, "Change Password clicked", Toast.LENGTH_SHORT).show()
            // Add your navigation or action here
        }

        setupMenuItem(
            itemId = R.id.itemWorkGroup,
            iconRes = R.drawable.ic_farmgroup,
            title = "Work group Code"
        ) {
            Toast.makeText(this, "Work group Code clicked", Toast.LENGTH_SHORT).show()
            // Add your navigation or action here
        }

        setupMenuItem(
            itemId = R.id.itemLogout,
            iconRes = R.drawable.ic_logout,
            title = "Logout"
        ) {
            showLogoutDialog()
        }
    }

    /**
     * Helper function to setup menu item with icon, title and click listener
     */
    private fun setupMenuItem(
        itemId: Int,
        iconRes: Int,
        title: String,
        onClick: () -> Unit
    ) {
        val menuItem = findViewById<View>(itemId)
        val container = menuItem.findViewById<RelativeLayout>(R.id.menuItemContainer)
        val icon = menuItem.findViewById<ImageView>(R.id.ivMenuIcon)
        val titleView = menuItem.findViewById<TextView>(R.id.tvMenuTitle)

        icon.setImageResource(iconRes)
        titleView.text = title

        container.setOnClickListener {
            onClick()
        }
    }

    /**
     * Show logout confirmation dialog
     */
    private fun showLogoutDialog() {
        AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout?")
            .setPositiveButton("Yes") { dialog, _ ->
                Toast.makeText(this, "Logged out successfully", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                // Add your logout logic here
                // Navigate to login screen
                // For now, just close all activities
                finishAffinity()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }
}